//
//  File.swift
//  ToDo_Staj
//
//  Created by Altay Kırlı 
//  Copyright © 2020 Altay Kırlı. All rights reserved.
//

import Foundation
import SwiftUI
import Combine

struct Task : Identifiable {
    var id = String()
    var toDoItem = String()
    
}
class TaskStore : ObservableObject {
    @Published var tasks = [Task]()
}


